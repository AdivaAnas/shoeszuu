package com.example.shoeszuu

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shoeszuu.R
import java.io.ByteArrayInputStream
import java.lang.Exception

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)
        val rv_dashboard:RecyclerView = findViewById(R.id.rv_dashboard)

        val txt_nama_admin:TextView= findViewById(R.id.txt_nama_admin)
        //dapatkan nama admin dari session
        val tiket:SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
        val nama_admin : String= tiket.getString("nama_admin",null).toString()
        txt_nama_admin.text = nama_admin

        //btn logout
        val btn_logout:Button = findViewById(R.id.btn_logout)
        btn_logout.setOnClickListener {
            //Menghapus session tiket
            val edittiket = tiket.edit()
            edittiket.clear()
            edittiket.commit()

            // pindah ke login
            val keluar:Intent=Intent(this,Login::class.java)
            startActivity(keluar)
            finish()
        }

        val id : MutableList<String> = mutableListOf()
        val produk:MutableList<String> = mutableListOf()
        val deskripsi:MutableList<String> = mutableListOf()
        val foto:MutableList<Bitmap> = mutableListOf()
        val harga:MutableList<String> = mutableListOf()

        val dbsepatu:SQLiteDatabase = openOrCreateDatabase( "shoeszuu", MODE_PRIVATE, null)
        val gali_sepatu = dbsepatu.rawQuery("SELECT * FROM produk", null)
        while (gali_sepatu.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(gali_sepatu.getBlob(3))
                val gambarbitmap:Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            }catch (e:Exception){
                val gambarbitmap:Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.inf)
                foto.add(gambarbitmap)
            }


            id.add(gali_sepatu.getString(0))
            produk.add(gali_sepatu.getString(1))
            deskripsi.add(gali_sepatu.getString(2))
            harga.add(gali_sepatu.getString(4))
        }
        val si = Sepatu_item(this, id,produk, deskripsi, harga, foto)

        rv_dashboard.adapter = si
        rv_dashboard.layoutManager = GridLayoutManager(this, 1)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener(){
            val pindah:Intent= Intent(this, Sepatu_tambah::class.java)
            startActivity(pindah)
        }
    }
}