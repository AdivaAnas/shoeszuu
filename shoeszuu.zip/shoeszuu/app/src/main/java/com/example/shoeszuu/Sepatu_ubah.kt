package com.example.shoeszuu

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import com.example.shoeszuu.R
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.lang.Exception

class Sepatu_ubah : AppCompatActivity() {
    var iv_upload : ImageView? = null
    var urlgambar : Uri? = null
    var bitmapgambar:Bitmap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sepatu_ubah)

        val id_produk_terpilih:String = intent.getStringExtra("id_produk_terpilih").toString()

        val dbsepatu:SQLiteDatabase = openOrCreateDatabase("shoeszuu", MODE_PRIVATE, null)
        val ambil = dbsepatu.rawQuery("SELECT * FROM produk WHERE id_produk = '$id_produk_terpilih'",null)
        if (ambil.moveToNext())
        {

            val isi_produk:String = ambil.getString(1)
            val isi_deskripsi:String = ambil.getString(2)
            val isi_foto:ByteArray = ambil.getBlob(3)
            val isi_harga:String = ambil.getString(4)

            val edt_produk:EditText=findViewById(R.id.edt_produk)
            val edt_deskripsi:EditText=findViewById(R.id.edt_deskripsi)
            val edt_harga:EditText=findViewById(R.id.edt_harga)
            val btn_simpan:Button=findViewById(R.id.btn_simpan)
            iv_upload = findViewById(R.id.iv_upload)
            edt_produk.setText(isi_produk)
            edt_deskripsi.setText(isi_deskripsi)
            edt_harga.setText(isi_harga)

            try {
                val bis = ByteArrayInputStream(isi_foto)
                val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
                iv_upload?.setImageBitmap(gambarbitmap)
            }catch (e: Exception){
                val gambarbitmap: Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.inf)
                iv_upload?.setImageBitmap(gambarbitmap)
            }
            iv_upload?.setOnClickListener {
                val bukagaleri : Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
                pilih_gambar.launch(bukagaleri)
            }
            btn_simpan.setOnClickListener {
                val produk_baru:String = edt_produk.text.toString()
                val deskripsi_baru:String = edt_deskripsi.text.toString()
                val harga_baru:String = edt_harga.text.toString()
                val bos = ByteArrayOutputStream()
                bitmapgambar?.compress(Bitmap.CompressFormat.JPEG, 100,bos)
                val bytearraygambar =bos.toByteArray()

                //val ubah = dbsepatu.rawQuery("UPDATE produk SET deskripsi='$deskripsi_baru',nama='$produk_baru' WHERE id_produk='$id_produk_terpilih'",null)
                //ubah.moveToNext()
                val sql = "UPDATE produk SET nama=?,deskripsi=?,foto_produk=?,harga=? WHERE id_produk='$id_produk_terpilih'"

                val statement = dbsepatu.compileStatement(sql)
                statement.clearBindings()
                statement.bindString(1,produk_baru)
                statement.bindString(2,deskripsi_baru)
                statement.bindBlob(3, bytearraygambar)
                statement.bindString(4, harga_baru)
                statement.executeUpdateDelete()

                val pindah:Intent=Intent(this,Dashboard::class.java)
                startActivity(pindah)
            }

        }



    }
    val pilih_gambar = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        if (it.resultCode == Activity.RESULT_OK){
            val gambardiperoleh = it.data

            if (gambardiperoleh!=null){
                //dapatkan url gambar
                urlgambar = gambardiperoleh.data

                //konversi ke bitmap
                bitmapgambar=MediaStore.Images.Media.getBitmap(contentResolver, urlgambar)
                iv_upload?.setImageBitmap(bitmapgambar)

            }
        }
    }
}