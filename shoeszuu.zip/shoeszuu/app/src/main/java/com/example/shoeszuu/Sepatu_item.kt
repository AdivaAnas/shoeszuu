package com.example.shoeszuu

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.shoeszuu.R

class Sepatu_item (val ini :Context, val id: MutableList<String>, val produk: MutableList<String>, val deskripsi:MutableList<String>, val harga:MutableList<String>, val foto:MutableList<Bitmap>) : RecyclerView.Adapter<Sepatu_item.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.sepatu_item, parent, false)
        return ViewHolder(view)
    }
    class ViewHolder (ItemView:View) : RecyclerView.ViewHolder(ItemView){
        val txt_produk:TextView = itemView.findViewById(R.id.txt_produk)
        val txt_deskripsi:TextView = itemView.findViewById(R.id.txt_deskripsi)
        val txt_harga:TextView = itemView.findViewById(R.id.txt_harga)
        val iv_foto:ImageView = itemView.findViewById(R.id.iv_foto)
        val btn_hapus:Button = itemView.findViewById(R.id.btn_hapus)
        val btn_ubah:Button = itemView.findViewById(R.id.btn_ubah)
    }

    override fun getItemCount(): Int {
        return produk.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_produk.text = produk.get(position)
        holder.txt_deskripsi.text = deskripsi.get(position)
        holder.iv_foto.setImageBitmap(foto.get(position))
        holder.txt_harga.text= harga.get(position)

        //btn hapus ditekan
        holder.btn_hapus.setOnClickListener {
            //dapatkan id_produk sesuai urutan dari tempat yang di tekan
            val id_produk_terpilih:String = id.get(position)
            //larikan ke activity sepatu_hapus
            val pindah:Intent = Intent(ini,Sepatu_hapus::class.java)
            pindah.putExtra("id_produk_terpilih", id_produk_terpilih)
            ini.startActivity(pindah)
        }
        holder.btn_ubah.setOnClickListener {
            val id_produk_terpilih:String = id.get(position)
            //larikan ke activity sepatu_ubah
            val pindah:Intent = Intent(ini,Sepatu_ubah::class.java)
            pindah.putExtra("id_produk_terpilih", id_produk_terpilih)
            ini.startActivity(pindah)
        }
    }
}