package com.example.shoeszuu

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.shoeszuu.R

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val username :EditText = findViewById(R.id.username)
        val password :EditText = findViewById(R.id.password)
        val btn_login :Button = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            val isi_username: String = username.text.toString()
            val isi_password: String = password.text.toString()

            val dbsepatu: SQLiteDatabase = openOrCreateDatabase("shoeszuu", MODE_PRIVATE, null)
            val query = dbsepatu.rawQuery("SELECT * FROM admin WHERE username ='$isi_username' AND password ='$isi_password'",null)
            val cek = query.moveToNext()

            if (cek) {
                val id_pelogin =query.getString(0)
                val username_pelogin =query.getString(1)
                val password_pelogin =query.getString(2)
                val nama_pelogin =query.getString(3)

                val session:SharedPreferences=getSharedPreferences("admin", MODE_PRIVATE)
                val buattiket = session.edit()

                buattiket.putString("id_admin",id_pelogin)
                buattiket.putString("username",username_pelogin)
                buattiket.putString("password",password_pelogin)
                buattiket.putString("nama_admin",nama_pelogin)
                buattiket.commit()

                val pindah:Intent= Intent(this,Dashboard::class.java)
                startActivity(pindah)
            }else{
                Toast.makeText(this,"Username atau password salah!",Toast.LENGTH_LONG).show()
            }
        }
    }
}
